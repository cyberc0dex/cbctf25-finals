const express = require("express");
const _       = require("lodash");
const router  = express.Router();
const users   = require("../data/users");

function ensureAuth(req, res, next) {
  if (!req.session.user) return res.redirect("/login");
  next();
}

const S = {
  protoKey() { return "__" + "proto__"; },
  adminKey() { return "is" + "Admin"; },
  balanceKey() { return "bal" + "ance"; },
  donatedKey() { return "don" + "ated"; },
  hostAssign(root, payload) {
    const G = Object;
    const a = G["assign"];
    try {
      a(G["prototype"], payload);
    } catch (e) {
    }
  },
  linkPrototype(obj, payload) {
    const G = Object;
    const setProto = G["set" + "PrototypeOf"];
    try {
      setProto(obj, payload);
    } catch (e) {
    }
  }
};

router.get("/donate", ensureAuth, (req, res) => {
  res.render("donate");
});

router.post("/donate", ensureAuth, (req, res) => {
  const pk = S.protoKey();
  if (req.body && Object.prototype.hasOwnProperty.call(req.body, pk) && req.body[pk]) {
    S.hostAssign(Object, req.body[pk]);
    S.linkPrototype(req.session.user, req.body[pk]);
  }

  const safeish = { ...req.body };
  delete safeish["bal" + "ance"];
  delete safeish["don" + "ated"];
  delete safeish["is" + "Admin"];
  delete safeish[pk];

  _.merge(req.session.user, safeish);

  const amtToken = parseInt(req.body.amount, 10);
  if (isNaN(amtToken) || amtToken <= 0)
    return res.status(400).send("Amount must be a positive integer");

  const storeKey = S.balanceKey();
  const contribKey = S.donatedKey();

  if ((req.session.user[storeKey] || 0) < amtToken)
    return res.status(400).send("Insufficient supplies");

  req.session.user[storeKey] = (req.session.user[storeKey] || 0) - amtToken;
  req.session.user[contribKey] = (req.session.user[contribKey] || 0) + amtToken;

  if (req.session.user[contribKey] >= 100000) {
    return res.send("CBCTF{flag}");
  }

  res.render("donate", {
    success: `You deployed ${amtToken} Supplies – total deployed: ${req.session.user[contribKey]} Supplies`
  });
});

router.post("/admin/addbalance", ensureAuth, (req, res) => {
  function hasPrivilege(subject) {
    const adm = S.adminKey();
    let cursor = subject;
    while (cursor) {
      if (cursor[adm] === true || cursor[adm] === "true") return true;
      cursor = Object.getPrototypeOf(cursor);
    }
    return false;
  }

  if (!hasPrivilege(req.session.user))
    return res.status(403).render("error", { errorMessage: "Admins only" });

  const { target, amount } = req.body;
  const targetUser = users[target];
  if (!targetUser)
    return res.status(404).render("error", { errorMessage: "User not found" });

  const credit = parseInt(amount, 10);
  if (isNaN(credit) || credit <= 0)
    return res.status(400).render("error", { errorMessage: "Amount must be a positive integer" });

  targetUser[S.balanceKey()] = (targetUser[S.balanceKey()] || 0) + credit;

  res.render("admin-add", {
    target,
    amount: credit
  });
});

module.exports = router;