const express = require("express");
const router  = express.Router();
const users   = require("../data/users");

router.get("/login", (req, res) => {
  res.render("login");
});

router.post("/login", (req, res) => {
  const { username, password } = req.body;
  const user = users[username];

  if (user && user.password === password) {
    req.session.user = user;
    return res.redirect("/donate");
  }
  res.render("login", { error: "Invalid credentials" });
});

router.get("/register", (req, res) => {
  res.render("register");
});

router.post("/register", (req, res) => {
  const { username, password } = req.body;

  if (users[username]) {
    return res.render("register", { error: "Username already exists" });
  }

  users[username] = {
    username,
    password,
    balance : 1000,
    isAdmin : false,
    donated : 0
  };

  req.session.user = users[username];
  res.redirect("/donate");
});

router.get("/logout", (req, res) => {
  req.session.destroy(() => res.redirect("/login"));
});

module.exports = router;
