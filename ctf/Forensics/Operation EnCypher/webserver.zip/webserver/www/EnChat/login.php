<?php
session_start();

$mysqli = new mysqli("localhost", "root", "", "chat_db");
if ($mysqli->connect_error) {
    die("DB connection failed");
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['user']);
    $password = trim($_POST['pass']);
    $hash = md5($password);

    $stmt = $mysqli->prepare("SELECT id, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($id, $stored_hash);
    $stmt->fetch();

    if ($stored_hash === $hash) {
        $_SESSION['uid'] = $id;
        header("Location: index.php");
        exit;
    } else {
        $error = "❌ Invalid credentials.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Encrypted Chat</title>
    <link rel="stylesheet" href="style.css">
<style>
    body {
    background: #f2f2f2;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}
</style>
</head>
<body>
    <div class="auth-container">
        <h2>🔐 Login</h2>
        <form method="POST" autocomplete="off">
            <input name="user" placeholder="Username" required>
            <input name="pass" type="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
        <?php if ($error): ?>
            <div class="msg error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <p>Don't have an account? <a href="register.php">Register here</a></p>
    </div>
</body>
</html>
