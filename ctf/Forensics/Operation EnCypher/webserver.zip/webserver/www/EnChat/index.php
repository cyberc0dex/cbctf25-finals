<?php
session_start();
if (!isset($_SESSION['uid'])) {
    die("Unauthorized. Please <a href='login.php'>log in</a>.");
}

include 'utils.php';

$mysqli = new mysqli("localhost", "root", "", "chat_db");
if ($mysqli->connect_error) {
    die("DB connection failed");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message'])) {
    $text = trim($_POST['message']);
    if ($text !== '') {
        $encrypted = xor_encrypt($text, $xor_key);
        $hex = str_to_hex($encrypted);
        $user_id = $_SESSION['uid'];
        $stmt = $mysqli->prepare("INSERT INTO messages (user_id, message, created_at) VALUES (?, ?, NOW())");
        $stmt->bind_param("is", $user_id, $hex);
        $stmt->execute();
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
}

$query = "
    SELECT messages.*, users.username 
    FROM messages 
    JOIN users ON messages.user_id = users.id 
    ORDER BY messages.created_at ASC
";
$res = $mysqli->query($query);

$usernames = [];
$res2 = $mysqli->query("SELECT id, username FROM users");
while ($row2 = $res2->fetch_assoc()) {
    $usernames[$row2['id']] = $row2['username'];
}

$user_colors = [];
$colors = ['#d9534f','#5bc0de','#5cb85c','#f0ad4e','#337ab7','#d946ef']; // stronger distinct colors
$color_index = 0;
foreach ($usernames as $id => $uname) {
    $user_colors[$id] = $colors[$color_index % count($colors)];
    $color_index++;
}

$current_user_id = $_SESSION['uid'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Encrypted Chat 💬</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header">
    <h2> 🔒 Encrypted Chat </h2>
    <div><a href="logout.php" class="logout-btn">Logout</a></div>
</div>

<div class="chat-container">
    <div class="chat" id="chat">
        <?php while ($row = $res->fetch_assoc()):
            $enc_msg = hex_to_str($row['message']);
            $decrypted = ($enc_msg === false) ? '[invalid message]' : xor_encrypt($enc_msg, $xor_key);
            $author = htmlspecialchars($row['username']);
            $created = date("M d, Y H:i", strtotime($row['created_at']));
            $is_current_user = ($row['user_id'] == $current_user_id);
            $author_color = $user_colors[$row['user_id']] ?? '#000';
            $msg_class = $is_current_user ? 'msg-right' : 'msg-left';
        ?>
        <div class="msg <?= $msg_class ?>" style="background-color: <?= $is_current_user ? '#dff0d8' : '#f7f7f7' ?>">
            <div class="meta">
                <span class="author" style="color: <?= $author_color ?>"><?= $author ?></span>
                <span class="time"><?= $created ?></span>
            </div>
            <div class="text">
                <?php if ($row['is_deleted']): ?>
                    <em class="deleted-msg">🚫 This message was deleted</em>
                <?php else: ?>
                    <?php
                    // Detect [image] links
                    if (preg_match('/^\[image\]\s*(https?:\/\/\S+)/i', $decrypted, $matches)) {
                        $img_url = htmlspecialchars($matches[1]);
                        echo "<img src=\"$img_url\" class=\"chat-image\">";
                    } else {
                        echo nl2br(htmlspecialchars($decrypted));
                    }
                    ?>
                <?php endif; ?>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
</div>

<form class="message-form" method="POST" action="">
    <input type="text" name="message" placeholder="Type your message..." autocomplete="off" required>
    <button type="submit">Send</button>
</form>

<script>
window.onload = function() {
    var chat = document.getElementById('chat');
    chat.scrollTop = chat.scrollHeight;
};
</script>

</body>
</html>
