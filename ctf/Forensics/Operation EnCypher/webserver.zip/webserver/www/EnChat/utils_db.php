<?php
function db_fetch_one($mysqli, $query, $types = "", ...$params) {
    $stmt = $mysqli->prepare($query);
    if (!$stmt) {
        die("DB Error: " . $mysqli->error);
    }
    if ($types) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    return $row;
}

function db_fetch_all($mysqli, $query, $types = "", ...$params) {
    $stmt = $mysqli->prepare($query);
    if (!$stmt) {
        die("DB Error: " . $mysqli->error);
    }
    if ($types) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $rows;
}

function db_exec($mysqli, $query, $types = "", ...$params) {
    $stmt = $mysqli->prepare($query);
    if (!$stmt) {
        die("DB Error: " . $mysqli->error);
    }
    if ($types) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $stmt->close();
    return true;
}
?>
