<?php
session_start();

$mysqli = new mysqli("localhost", "root", "", "chat_db");
if ($mysqli->connect_error) {
    die("DB connection failed");
}

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if ($username && $password) {
        $hash = md5($password); // 👈 consider using password_hash() for real apps

        // Check if username already exists
        $check = $mysqli->prepare("SELECT id FROM users WHERE username = ?");
        $check->bind_param("s", $username);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $message = "❌ Username already exists. Try another.";
        } else {
            $stmt = $mysqli->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
            $stmt->bind_param("ss", $username, $hash);
            if ($stmt->execute()) {
                $message = "✅ Registration successful! <a href='login.php'>Login here</a>";
            } else {
                $message = "❌ Registration failed. Try again.";
            }
            $stmt->close();
        }

        $check->close();
    } else {
        $message = "❌ Please fill all fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register - Encrypted Chat</title>
    <link rel="stylesheet" href="style.css">
</head>
<style>
    body {
    background: #f2f2f2;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}
</style>
<body>
    <div class="auth-container">
        <h2>📝 Register</h2>
        <form method="POST" autocomplete="off">
            <input type="text" name="username" placeholder="Enter username" required>
            <input type="password" name="password" placeholder="Enter password" required>
            <button type="submit">Register</button>
        </form>
        <?php if ($message): ?>
            <div class="msg"><?= $message ?></div>
        <?php endif; ?>
        <p>Already have an account? <a href="login.php">Login here</a></p>
    </div>
</body>
</html>
