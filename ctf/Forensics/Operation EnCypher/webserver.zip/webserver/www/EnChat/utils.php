<?php
function xor_encrypt($input, $key) {
    $output = '';
    for ($i = 0; $i < strlen($input); $i++) {
        $output .= chr(ord($input[$i]) ^ ord($key[$i % strlen($key)]));
    }
    return $output;
}

function str_to_hex($string) {
    return bin2hex($string);
}

function hex_to_str($hex) {
    return hex2bin($hex);
}


$k1 = chr(ord("u") - 1);       
$k2 = "4";
$k3 = chr(0x59);               
$k4 = chr(ord("m") - 1);      
$k5 = "0";
$k6 = strtoupper("r");         
$k7 = "_";
$k8 = chr(53);                 
$k9 = "W";
$k10 = "!";
$k11 = "f";
$k12 = chr(ord("u") + 1);      

$xor_key = $k1 . $k2 . $k3 . $k4 . $k5 . $k6 . $k7 . $k8 . $k9 . $k10 . $k11 . $k12;
?>
