<?php

$browser = array (
  'name' => 
  array (
    0 => 'Mozilla Firefox',
    1 => 'Google Chrome',
    2 => 'Internet Explorer',
    3 => 'Microsoft Edge',
  ),
  'path' => 
  array (
    0 => 'C:/Program Files/Mozilla Firefox/firefox.exe',
    1 => 'C:/Program Files/Google/Chrome/Application/chrome.exe',
    2 => 'C:/Program Files/Internet Explorer/iexplore.exe',
    3 => 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  ),
);

?>
